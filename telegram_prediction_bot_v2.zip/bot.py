import requests
import time
import os
from datetime import datetime

BOT_TOKEN = os.getenv('BOT_TOKEN')
DEEPSEEK_KEY = os.getenv('DEEPSEEK_KEY')
YOUR_ID = "127801716"

def send_message(text):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    data = {"chat_id": YOUR_ID, "text": text, "parse_mode": "Markdown"}
    try:
        requests.post(url, data=data)
        print(f"[{datetime.now()}] ✅ Отправлено")
    except Exception as e:
        print(f"[{datetime.now()}] ❌ Ошибка: {e}")

def get_prediction():
    prompt = "Дай 1 прогноз на сегодняшний футбольный матч. Формат: Команды, прогноз, коэффициент, анализ"
    
    headers = {
        "Authorization": f"Bearer {DEEPSEEK_KEY}",
        "Content-Type": "application/json"
    }
    
    data = {
        "model": "deepseek-chat",
        "messages": [{"role": "user", "content": prompt}]
    }
    
    try:
        response = requests.post(
            "https://api.deepseek.com/v1/chat/completions",
            headers=headers,
            json=data,
            timeout=30
        )
        if response.status_code == 200:
            result = response.json()
            return result['choices'][0]['message']['content']
        else:
            return "Не удалось получить прогноз"
    except:
        return "Ошибка соединения"

def main():
    print(f"[{datetime.now()}] 🤖 Бот запущен!")
    send_message("✅ Бот запущен на сервере Bothost!")
    
    while True:
        now = datetime.now()
        current_time = now.strftime("%H:%M")
        
        if current_time in ["09:00", "15:00", "20:00"]:
            prediction = get_prediction()
            send_message(f"📊 *Прогноз*\n\n{prediction}")
            time.sleep(61)
        time.sleep(30)

if __name__ == "__main__":
    main()
